<template>
  <div class="text-center">
    <h1>Dashboard screen</h1>
  </div>
</template>

<script>
// @ is an alias to /src

export default {
  name: 'home',
};
</script>
