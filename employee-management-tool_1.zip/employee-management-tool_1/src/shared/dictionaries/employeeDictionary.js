const empolyees = {
  addEmployeeTitle: 'Add Employee',
  allEmployeeTitle: 'All Employee',
  resetText: 'Reset',
  submitText: 'Submit',
  teamsText: 'Teams',
  skillText: 'Skill',
  fullNameText: 'Your Full Name',
  emailText: 'Email Address',
  emailDescription: 'We\'ll never share your email with anyone else.',
  addEmployeeHeaderText: 'Enter Employee Details',
  listEmployeeHeaderText: 'Employee Details',
};

export default empolyees;
