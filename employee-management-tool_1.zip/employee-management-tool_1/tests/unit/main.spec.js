describe('In main.js', () => {
  it('it should trigger application', () => {
    expect(true).toBe(true);

    //   document.body.innerHTML = '<div id="app"></div>';
    //   // eslint-disable-next-line global-require
    //   require('../../src/main.js');

  //   const divElement = document.getElementById('app');
  //   expect(divElement).toBeTruthy();
  //   expect(divElement.className).toEqual('container');
  });

  // test('Can mount app', () => {
  //   document.body.innerHTML =
  //     '<div id="app">' +
  //     '</div>';


  //   // Executes main file
  //   require('../src/main');

//   const pElement = document.getElementById('example');
//   expect(pElement).toBeTruthy();
//   expect(pElement.textContent).toEqual('Example');
});
